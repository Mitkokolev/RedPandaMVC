﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace RedPandaCoreMvc.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }

        public DbSet<RedPanda> RedPandas { get; set; }
  
    }
}

